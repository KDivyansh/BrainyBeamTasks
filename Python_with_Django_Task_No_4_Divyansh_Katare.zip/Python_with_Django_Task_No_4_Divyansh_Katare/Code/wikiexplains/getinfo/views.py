from django.shortcuts import render

# Create your views here.
import wikipediaapi
from django.http import HttpResponse
from .forms import WordForm

def get_wiki_explanation(request):
    if request.method == 'POST':
        form = WordForm(request.POST)
        if form.is_valid():
            word = form.cleaned_data['word']
            
            # Initialize the Wikipedia API with a custom User-Agent
            wiki = wikipediaapi.Wikipedia(
                language='en',
                user_agent='getinfo (https://tempsite.com; temp@mail.com)'
            )

            page = wiki.page(word)

            if page.exists():
                # Create the .txt file
                file_name = f'{word}_explanation.txt'
                with open(file_name, 'w', encoding='utf-8') as file:
                    file.write(page.text)

                # Serve the file as a response
                with open(file_name, 'r', encoding='utf-8') as file:
                    response = HttpResponse(file.read(), content_type='text/plain')
                    response['Content-Disposition'] = f'attachment; filename="{file_name}"'
                    return response
            else:
                return HttpResponse("The word does not exist on Wikipedia.")
    else:
        form = WordForm()

    return render(request, 'getinfo/index.html', {'form': form})
