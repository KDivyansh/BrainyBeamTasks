from django.db import models

# Create your models here

class Question(models.Model):
    text = models.CharField(max_length=255)
    # Track correct option directly or store right answer in the view logic
    def __str__(self):
        return self.text

class Option(models.Model):
    question = models.ForeignKey(Question, related_name='options', on_delete=models.CASCADE)
    text = models.CharField(max_length=255)
    is_correct = models.BooleanField(default=False)

    def __str__(self):
        return self.text
