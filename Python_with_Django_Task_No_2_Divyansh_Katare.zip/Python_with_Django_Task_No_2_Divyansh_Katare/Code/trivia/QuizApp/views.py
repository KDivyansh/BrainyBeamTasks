# Create your views here.
from django.shortcuts import render
from .models import Question, Option
from .forms import QuizForm

def quiz_view(request):
    questions = Question.objects.all()[:10]
    if request.method == 'POST':
        form = QuizForm(request.POST, questions=questions)
        if form.is_valid():
            correct_answers = 0
            wrong_answers = 0
            for question in questions:
                selected_option_id = form.cleaned_data[f'question_{question.id}']
                selected_option = Option.objects.get(id=selected_option_id)
                if selected_option.is_correct:
                    correct_answers += 1
                else:
                    wrong_answers += 1

            return render(request, 'quiz_result.html', {
                'correct': correct_answers,
                'wrong': wrong_answers,
                'total': len(questions),
            })
    else:
        form = QuizForm(questions=questions)

    return render(request, 'quiz.html', {'form': form})
