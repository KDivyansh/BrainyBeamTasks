from django.urls import path
from .views import docx_to_pdf_view

urlpatterns = [
    path('', docx_to_pdf_view, name='docx_to_pdf'),
]
