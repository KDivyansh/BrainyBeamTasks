from django import forms

class UploadDocxForm(forms.Form):
    docx_file = forms.FileField(label='Select a .docx file')
