from django.shortcuts import render

# Create your views here.
import os
import pdfkit
from django.shortcuts import render
from django.http import HttpResponse
from .forms import UploadDocxForm
from docx import Document

def docx_to_pdf_view(request):
    if request.method == 'POST':
        form = UploadDocxForm(request.POST, request.FILES)
        if form.is_valid():
            docx_file = request.FILES['docx_file']
            doc = Document(docx_file)

            # Save the document as HTML temporarily
            temp_html = "temp.html"
            with open(temp_html, 'w', encoding='utf-8') as f:
                for para in doc.paragraphs:
                    f.write(f"<p>{para.text}</p>")

            # Convert HTML to PDF
            pdf_output = "output.pdf"
            pdfkit.from_file(temp_html, pdf_output)

            # Serve the PDF file as an HTTP response
            with open(pdf_output, 'rb') as pdf:
                response = HttpResponse(pdf.read(), content_type='application/pdf')
                response['Content-Disposition'] = 'attachment; filename="converted.pdf"'

            # Clean up temporary files
            os.remove(temp_html)
            os.remove(pdf_output)

            return response
    else:
        form = UploadDocxForm()

    return render(request, 'converter/upload.html', {'form': form})
