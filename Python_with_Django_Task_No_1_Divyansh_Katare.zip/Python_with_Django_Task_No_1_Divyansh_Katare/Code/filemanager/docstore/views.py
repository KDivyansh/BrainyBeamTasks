from django.shortcuts import render

from .forms import UploadFileForm
from django.http import HttpResponse

def upload_file(request):
    if request.method == 'POST':
        form = UploadFileForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return HttpResponse("File successfully uploaded!")
    else:
        form = UploadFileForm()
    
    return render(request, 'upload_file.html', {'form': form})
