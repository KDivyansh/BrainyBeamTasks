from django.db import models

# Create your models here.
import os

def file_directory_path(instance, filename):
    # Get file extension
    ext = filename.split('.')[-1]
    
    # Define folder based on file extension
    if ext in ['pdf']:
        return f'pdf/{filename}'
    elif ext in ['docx']:
        return f'doc/{filename}'
    elif ext in ['jpg', 'jpeg', 'png']:
        return f'image/{filename}'
    else:
        return f'others/{filename}'

class UploadFile(models.Model):
    file = models.FileField(upload_to=file_directory_path)
    uploaded_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return os.path.basename(self.file.name)