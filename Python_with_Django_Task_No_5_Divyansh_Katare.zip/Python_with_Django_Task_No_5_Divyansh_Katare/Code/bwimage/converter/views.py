from django.shortcuts import render, redirect

# Create your views here.
from .forms import ImageUploadForm
from .models import ImageModel
from PIL import Image
from django.core.files.base import ContentFile
import io

def convert_to_bw(image):
    pil_image = Image.open(image)
    bw_image = pil_image.convert('L')
    return bw_image

def upload_image(request):
    if request.method == 'POST':
        form = ImageUploadForm(request.POST, request.FILES)
        if form.is_valid():
            image_instance = form.save(commit=False)
            bw_image = convert_to_bw(image_instance.original_image)
            
            image_io = io.BytesIO()
            bw_image.save(image_io, format='PNG')
            image_instance.bw_image.save(f'bw_{image_instance.original_image.name}', ContentFile(image_io.getvalue()), save=False)
            
            image_instance.save()
            return redirect('success')
    else:
        form = ImageUploadForm()
    return render(request, 'converter/upload_image.html', {'form': form})

def success(request):
    return render(request, 'converter/success.html')
