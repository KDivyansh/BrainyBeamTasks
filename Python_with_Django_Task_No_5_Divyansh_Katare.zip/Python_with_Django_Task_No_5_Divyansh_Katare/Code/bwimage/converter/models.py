from django.db import models

# Create your models here.

class ImageModel(models.Model):
    original_image = models.ImageField(upload_to='originals/')
    bw_image = models.ImageField(upload_to='black_and_white/', blank=True)

    def __str__(self):
        return f"Image {self.id}"